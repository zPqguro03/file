require('dotenv').config();

const fs = require('fs');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api');
const bedrock = require('bedrock-protocol');
const socks = require('socks').SocksClient;
const net = require('net');






const PROJECT_DIR = '../vps1_temp/';

const ACCOUNTS_FILE = path.join(PROJECT_DIR, 'accounts.json');

const LOG_DIR = path.join(__dirname, 'logs');

const HOST = process.env.HOST;

const PORT = parseInt(process.env.PORT) || 19132;

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';

const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || '';

const MAX_RETRY_ATTEMPTS = 5;

const BASE_RETRY_DELAY = 60000;

const RECONNECTION_STAGGER_MS = 6500;

const TARGET_TRADER_NAME = process.env.TARGET_TRADER_NAME || 'X_MITO_X';
const TARGET_TRADER_NAME2 = process.env.TARGET_TRADER_NAME2 || 'CPlusPluss';




const SCANNER_BOT_ALIAS = process.env.SCANNER || ''; 

const TOKEN_ITEM_NETWORK_ID = 551; 
const POTION_NETWORK_ID = 453;
const KEY_ITEM_NETWORK_ID = 131; 
const HOTDOG_ITEM_NETWORK_ID = -967; 

let canTriggerMassLogin = true;
let isScannerModeEnabled = true;
const DAILY_STATE_FILE = path.join(PROJECT_DIR, 'daily_state.json');






const botMap = {};

const botStopped = {};

const restartAttempts = {};

let reconnectionQueue = [];

let reconnectionQueueTimer = null;

const commandQueue = {};

const cmdExecutorFlag = {};

let requestId = -27;

let botConfigs;

let currentSequenceId = 0; 

const linkingBots = new Set(); 

let dailyState = { lastRun: 0 };




let quitSequenceTimeout = null; 
let isQuitPending = false;      







process.on('unhandledRejection', (reason, promise) => {
    writeLog(`[CRASH FATALE - UNHANDLED REJECTION] RAGIONE: ${reason?.stack || reason}`);
    sendTG(`⚠️ **ATTENZIONE:** Rifiuto Promise non gestito! Avvio riavvio coordinato di tutti i bot.`);

    
    
    botConfigs.forEach(cfg => {
        const alias = cfg.alias;
        if (!botStopped[alias] && !reconnectionQueue.includes(alias)) {
            const client = botMap[alias];
            
            if (client?._online) {
                client.emit('error', new Error('Recovery da Unhandled Rejection'));
            } 
            
            else {
                bindConnectionEvents(alias, {}).setOffline('unhandled_rejection_recovery');
            }
        }
    });
});


process.on('uncaughtException', (error) => {
    writeLog(`[CRASH FATALE - UNCAUGHT EXCEPTION] RAGIONE: ${error.stack || error}`);
    sendTG(`🚨 **CRITICO:** Crash sincrono! Il processo è stato terminato. Controllare i log. Causa: ${error.message.substring(0, 100)}...`);
    process.exit(1); 
});


try {
    botConfigs = JSON.parse(fs.readFileSync(ACCOUNTS_FILE));
} catch {
    writeLog(`Errore caricando ${path.basename(ACCOUNTS_FILE)}: file non trovato. Inizializzo array vuoto.`);
    botConfigs = [];
    fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(botConfigs, null, 2));
}


if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
const dayStamp = new Date().toISOString().slice(0, 10).replace(/-/g, '_');
const logStream = fs.createWriteStream(path.join(LOG_DIR, `bedrock_afk_${dayStamp}.log`), { flags: 'a' });




const telegramBot = TELEGRAM_BOT_TOKEN ? new TelegramBot(TELEGRAM_BOT_TOKEN, { polling: true }) : null;






function writeLog(msg) {
    const entry = `[${new Date().toISOString()}] ${msg}`;
    console.log(entry);
    logStream.write(entry + '\n');
}


const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));






function cancelSequentialQuit() {
    if (isQuitPending) {
        clearTimeout(quitSequenceTimeout);
        isQuitPending = false;
        writeLog('[SEQUENZA] Uscita annullata a causa di un segnale bonus o di un nuovo comando.');
        sendTG('🎉 **Uscita Annullata!** Rilevato un segnale di token bonus. I bot rimangono online.');
    }
}


function processReconnectionQueue() {
    if (reconnectionQueue.length === 0) return;

    writeLog(`[QUEUE] Elaborazione coda per ${reconnectionQueue.length} bot.`);

    const botsToRestart = [...reconnectionQueue];
    reconnectionQueue = [];

    botsToRestart.sort(() => 0.5 - Math.random());

    botsToRestart.forEach((alias, index) => {
        const cfg = botConfigs.find(o => o.alias === alias);
        if (cfg && !botStopped[alias]) {
            const attempts = restartAttempts[alias] || 1;
            const backoffDelay = BASE_RETRY_DELAY * Math.pow(2, attempts - 1) + Math.random() * 5000;
            const staggerDelay = index * RECONNECTION_STAGGER_MS;
            const totalDelay = staggerDelay + backoffDelay;

            writeLog(`[QUEUE] ${alias} (Tentativo ${attempts}) riavvierà tra ${(totalDelay / 1000).toFixed(1)}s (Stagger: ${staggerDelay/1000}s + Backoff: ${backoffDelay/1000}s)`);
            
            createBedrockBot(cfg, totalDelay);
        }
    });

    clearTimeout(reconnectionQueueTimer);
    reconnectionQueueTimer = null;
}



function loadDailyState() {
    try {
        if (fs.existsSync(DAILY_STATE_FILE)) {
            const data = fs.readFileSync(DAILY_STATE_FILE, 'utf8');
            dailyState = JSON.parse(data);
            writeLog(`[SCHEDULER] Stato del daily caricato. Ultima esecuzione: ${new Date(dailyState.lastRun).toLocaleString()}`);
        } else {
            writeLog(`[SCHEDULER] File di stato non trovato. Ne verrà creato uno nuovo alla prima esecuzione.`);
            saveDailyState(); 
        }
    } catch (err) {
        writeLog(`[SCHEDULER ERROR] Impossibile leggere il file di stato: ${err.message}`);
    }
}


function saveDailyState() {
    try {
        fs.writeFileSync(DAILY_STATE_FILE, JSON.stringify(dailyState, null, 2));
    } catch (err) {
        writeLog(`[SCHEDULER ERROR] Impossibile scrivere sul file di stato: ${err.message}`);
    }
}






function sendTG(txt) {
    if (telegramBot && TELEGRAM_CHAT_ID) {
        telegramBot.sendMessage(TELEGRAM_CHAT_ID, txt, { parse_mode: 'Markdown' })
            .catch(err => writeLog(`[Telegram Error] Invio fallito: ${err.code} - ${err.response?.body?.description || err.message}`));
    }
}


function reply(msg, html) {
    telegramBot?.sendMessage(msg.chat.id, html, { parse_mode: 'HTML' })
        .catch(err => writeLog(`[Telegram Error] Risposta fallita: ${err.code} - ${err.response?.body?.description || err.message}`));
}






function queueCommand(alias, cmd) {
    if (!botMap[alias]?._online) return;
    const q = (commandQueue[alias] ||= []);
    q.push(cmd);
    if (q.length > 20) {
        q.splice(0, q.length - 20);
        writeLog(`[QUEUE] ${alias} overflow, shrink.`);
    }
}


function immediateCommand(alias, cmd) {
    const client = botMap[alias];
    if (!client?._online) {
        writeLog(`[CMD FAIL] ${alias}: Offline, non posso inviare comando immediato: ${cmd}`);
        return;
    }
    writeLog(`[EXEC IMMED] ${alias} -> ${cmd}`);
    client.write('text', {
        type: 'chat',
        needs_translation: false,
        source_name: client.username,
        xuid: '',
        platform_chat_id: '',
        filtered_message: '',
        message: cmd
    });
}


function startCommandExecutor(alias, client) {
    if (cmdExecutorFlag[alias]) return;
    cmdExecutorFlag[alias] = true;
    const exec = () => {
        if (!client._online) {
            cmdExecutorFlag[alias] = false;
            clearTimeout(client._executorTimer);
            return;
        }
        const q = commandQueue[alias];
        if (q?.length) {
            const c = q.shift();
            writeLog(`[EXEC] ${alias} -> ${c}`);
            client.write('text', {
                type: 'chat',
                needs_translation: false,
                source_name: client.username,
                xuid: '',
                platform_chat_id: '',
                filtered_message: '',
                message: c
            });
        }
        client._executorTimer = setTimeout(exec, 3000 + Math.random() * 2000);
    };
    exec();
}


function scheduleLoop(alias, client, cmd, baseMs) {
    if (!client._online) return;
    const makeLoop = () => {
        if (!client._online) return;
        queueCommand(alias, cmd);
        client._loops[cmd] = setTimeout(makeLoop, baseMs + Math.random() * 40000);
    };
    client._loops ??= {};
    client._loops[cmd] = setTimeout(makeLoop, baseMs + Math.random() * 40000);
}


function startAutoTrashLoop(alias, client) {
    if (!client._online) return;
    
    const autoTrash = async () => {
        if (!client._online) return;
        
        writeLog(`[AUTO TRASH] ${alias}: Avvio pulizia automatica programmata.`);
        await trashUnwantedItems(client, alias);
        
        if (client._online) {
            client._autoTrashTimer = setTimeout(autoTrash, 600000); 
        }
    };
    
    
    client._autoTrashTimer = setTimeout(autoTrash, 600000);
}






function countInventoryTokens(client) {
    
    
    
    if (!client.inventory || !client.inventory.inventory) {
        return 0;
    }
    const playerInventory = client.inventory.inventory;
    let totalTokens = 0;

    for (const item of playerInventory) {
        
        if (item && item.network_id === TOKEN_ITEM_NETWORK_ID) {
            totalTokens += item.count;
        }
    }
    return totalTokens;
}


function countInventoryKeys(client) {
    if (!client.inventory || !client.inventory.inventory) {
        return 0;
    }
    const playerInventory = client.inventory.inventory;
    let totalKeys = 0;

    for (const item of playerInventory) {
        if (item && item.network_id === KEY_ITEM_NETWORK_ID) {
            totalKeys += item.count;
        }
    }
    return totalKeys;
}


function countInventoryHotdogs(client) {
    if (!client.inventory || !client.inventory.inventory) {
        return 0;
    }
    const playerInventory = client.inventory.inventory;
    let totalHotdogs = 0;

    for (const item of playerInventory) {
        if (item && item.network_id === HOTDOG_ITEM_NETWORK_ID) {
            totalHotdogs += item.count;
        }
    }
    return totalHotdogs;
}


function debugInventoryPacket(alias, packet) {
    try {
        const netherStarStacks = (packet.input || []).filter(item => item && item.network_id === 551);
        if (netherStarStacks.length > 0) {
            const totalNetherStars = netherStarStacks.reduce((sum, stack) => sum + stack.count, 0);
            writeLog(`  [!] Found ${netherStarStacks.length} Nether Star stacks (Total: ${totalNetherStars} items)`);
        }
    } catch (e) {
        writeLog(`[DEBUG ERROR] ${alias}: ${e.message}`);
    }
}


function setupInventoryContentListener(client) {
    
    client.on('inventory_content', (packet) => {
        const key = packet.window_id === 0 ? "inventory" : packet.window_id;
        client.inventory[key] = packet.input;
        debugInventoryPacket(client.alias, packet);
    });

    
    client.on('inventory_slot', (packet) => {
        const key = packet.window_id === 0 ? "inventory" : packet.window_id;
        
        
        if (client.inventory[key] && Array.isArray(client.inventory[key])) {
            
            client.inventory[key][packet.slot] = packet.item;
            
        }
    });
}

async function handleTradeGUI(client, windowId, alias) {
    const TARGET_ITEM_SLOTS = [9, 10, 18, 19, 27, 28, 29, 36, 37, 38, 39, 45, 46, 47, 48];
    const ACCEPT_BUTTON_SLOT = 12;
    await sleep(1000);

    const playerInventory = client.inventory['inventory'];
    if (!playerInventory || !Array.isArray(playerInventory)) {
        return;
    }

    const netherStarSlots = [];
    for (let i = 0; i < playerInventory.length; i++) {
        const item = playerInventory[i];
        if (item && item.network_id !== 0) {
            netherStarSlots.push({
                slot: i,
                count: item.count,
                stack_id: item.stack_id
            });
        }
    }

    if (netherStarSlots.length === 0) {
        client.queue('container_close', {
            window_id: windowId,
            server: false
        });
        return;
    }

    writeLog(`[TRADE] ${alias}: Trovati ${netherStarSlots.length} stack. Inizio trasferimento...`);

    let stacksMoved = 0;
    for (const source of netherStarSlots) {
        if (stacksMoved >= TARGET_ITEM_SLOTS.length) break;
        const targetSlot = TARGET_ITEM_SLOTS[stacksMoved];

        try {
            let sourceContainerId;
            if (source.slot >= 0 && source.slot <= 8) {
                sourceContainerId = 'hotbar';
            } else if (source.slot >= 9 && source.slot <= 35) {
                sourceContainerId = 'inventory';
            } else {
                continue;
            }

            const takeRequestId = requestId;
            requestId -= 2;
            const takeRequest = { "requests": [{ "request_id": takeRequestId, "actions": [{ "type_id": "take", "count": source.count, "source": { "slot_type": { "container_id": sourceContainerId }, "slot": source.slot, "stack_id": source.stack_id }, "destination": { "slot_type": { "container_id": "cursor" }, "slot": 0, "stack_id": 0 } }], "custom_names": [], "cause": -1 }] };
            client.queue('item_stack_request', takeRequest);

            const responsePacket = await new Promise((resolve, reject) => {
                const timeout = setTimeout(() => {
                    client.removeListener('item_stack_response', listener);
                    reject(new Error(`Timeout: Nessuna risposta dal server per request_id ${takeRequestId}`));
                }, 5000);

                const listener = (packet) => {
                    const matchingResponse = packet.responses.find(r => r.request_id === takeRequestId);
                    if (matchingResponse) {
                        clearTimeout(timeout);
                        client.removeListener('item_stack_response', listener);
                        resolve(packet);
                    }
                };
                client.on('item_stack_response', listener);
            });

            const matchingResponse = responsePacket.responses.find(r => r.request_id === takeRequestId);
            if (!matchingResponse || matchingResponse.status !== 'ok') {
                throw new Error(`Richiesta TAKE fallita o risposta non valida. Status: ${matchingResponse?.status}`);
            }
            if (!matchingResponse.containers || !Array.isArray(matchingResponse.containers)) {
                throw new Error("Risposta OK ma senza l'array 'containers'.");
            }
            const cursorEntry = matchingResponse.containers.find(c => c.slot_type.container_id === 'cursor');
            if (!cursorEntry || !cursorEntry.slots || cursorEntry.slots.length === 0) {
                throw new Error("Risposta OK ma non è stato trovato nessun item sul cursore.");
            }

            const newStackId = cursorEntry.slots[0].item_stack_id;

            const placeRequestId = requestId;
            requestId -= 2;
            const placeRequest = { "requests": [{ "request_id": placeRequestId, "actions": [{ "type_id": "place", "count": source.count, "source": { "slot_type": { "container_id": "cursor" }, "slot": 0, "stack_id": newStackId }, "destination": { "slot_type": { "container_id": "container" }, "slot": targetSlot, "stack_id": 0 } }], "custom_names": [], "cause": -1 }] };
            client.queue('item_stack_request', placeRequest);

            await sleep(500);
            stacksMoved++;

        } catch (err) {
            writeLog(`[FATAL TRADE ERROR] ${alias}: La transazione è fallita. Causa: ${err.message}`);
            break;
        }
    }

    if (stacksMoved > 0) {
        sendTG(`✅ *${alias}:* ${stacksMoved} stack spostato/i. Inizio fase di attivazione.`);

        const activationLoop = async () => {
            if (!client._online || client._tradeLoop === false) return;

            const tradeGuiInventory = client.inventory[windowId];
            if (!tradeGuiInventory || !tradeGuiInventory[ACCEPT_BUTTON_SLOT]) {
                writeLog(`[TRADE] Oggetto di attivazione non trovato.`);
                client.emit('container_close');
                return;
            }

            const targetItem = tradeGuiInventory[ACCEPT_BUTTON_SLOT];
            const currentItemStackId = targetItem.stack_id;
            const currentItemCount = targetItem.count;
            const takeRequestId = requestId;
            requestId -= 2;

            try {
                const takeRequest = { "requests": [{ "request_id": takeRequestId, "actions": [{ "type_id": "take", "count": currentItemCount, "source": { "slot_type": { "container_id": "container" }, "slot": ACCEPT_BUTTON_SLOT, "stack_id": currentItemStackId }, "destination": { "slot_type": { "container_id": "cursor" }, "slot": 0, "stack_id": 0 } }], "custom_names": [], "cause": 6 }] };
                client.queue('item_stack_request', takeRequest);

                const responsePacket = await new Promise((resolve, reject) => {
                    const timeout = setTimeout(() => {
                        client.removeListener('item_stack_response', listener);
                        reject(new Error(`Timeout in attesa di risposta per attivazione-take (Req ID: ${takeRequestId})`));
                    }, 5000);
                    const listener = (packet) => {
                        const matchingResponse = packet.responses.find(r => r.request_id === takeRequestId);
                        if (matchingResponse) {
                            clearTimeout(timeout);
                            client.removeListener('item_stack_response', listener);
                            resolve(packet);
                        }
                    };
                    client.on('item_stack_response', listener);
                });

                const matchingResponse = responsePacket.responses.find(r => r.request_id === takeRequestId);
                if (!matchingResponse || matchingResponse.status !== 'ok') throw new Error(`Attivazione-take fallita. Status: ${matchingResponse?.status}`);
                if (!matchingResponse.containers) throw new Error("Risposta OK ma senza 'containers'.");

                const cursorEntry = matchingResponse.containers.find(c => c.slot_type.container_id === 'cursor');
                if (!cursorEntry || !cursorEntry.slots || cursorEntry.slots.length === 0) throw new Error("Nessun item sul cursore dopo attivazione-take.");

                const newStackId = cursorEntry.slots[0].item_stack_id;

                const placeRequestId = requestId;
                requestId -= 2;
                const placeRequest = { "requests": [{ "request_id": placeRequestId, "actions": [{ "type_id": "place", "count": currentItemCount, "source": { "slot_type": { "container_id": "cursor" }, "slot": 0, "stack_id": newStackId }, "destination": { "slot_type": { "container_id": "hotbar" }, "slot": 0, "stack_id": 0 } }], "custom_names": [], "cause": 6 }] };
                client.queue('item_stack_request', placeRequest);

            } catch (err) {
                writeLog(`[FATAL ACTIVATION ERROR] ${alias}: ${err.message}`);
                client._tradeLoop = false;
                client.removeAllListeners('container_close');
                client.queue('container_close', {
                    window_id: windowId,
                    server: false
                });
                return;
            }

            await sleep(3000);
            if (client._tradeLoop) activationLoop();
        };

        client._tradeLoop = true;
        activationLoop();

        client.once('container_close', () => {
            client._tradeLoop = false;
            sendTG(`🔄 *${alias}:* Operazione di trade terminata o annullata.`);
            writeLog(`[TRADE] ${alias}: Finestra trade chiusa.`);
        });

    } else {
        writeLog(`[ERROR] ${alias}: Nessun item è stato spostato con successo.`);
        sendTG(`❌ *${alias}:* Errore critico durante il trade - nessun item spostato.`);
    }
}








function startAllBotsSequentially() {
    writeLog('[SEQUENZA] Interrompo azioni precedenti e avvio join di tutti i bot...');
    currentSequenceId++; 
    const thisSequenceId = currentSequenceId;

    const shuffledConfigs = [...botConfigs].sort(() => 0.5 - Math.random());
    shuffledConfigs.forEach((config, i) => {
        const alias = config.alias;

        
        
        
        if (alias === SCANNER_BOT_ALIAS && botMap[alias]?._online) {
            writeLog(`[SEQUENZA] Lo scanner ${alias} è già online. Lo lascio attivo.`);
            delete botStopped[alias]; 
            return; 
        }
        

        const delay = i * RECONNECTION_STAGGER_MS + Math.random() * 500;
        setTimeout(() => {
            if (currentSequenceId !== thisSequenceId) return; 
            
            delete botStopped[alias];
            delete restartAttempts[alias];
            if (botMap[alias]) safeStopBot(alias);
            createBedrockBot(config, 0);
        }, delay);
    });
}

function stopWorkerBotsSequentially() {
    writeLog('[SEQUENZA] Interrompo azioni precedenti e avvio stop dei worker...');
    currentSequenceId++; 
    const thisSequenceId = currentSequenceId;
    
    const workerBots = Object.keys(botMap).filter(alias => alias !== SCANNER_BOT_ALIAS && botMap[alias]?._online);
    sendTG(`👋 **Segnale di Uscita Rilevato!** Disconnessione di ${workerBots.length} bot in corso...`);
    
    workerBots.forEach((alias, i) => {
        const delay = i * 13000;
        setTimeout(() => {
            if (currentSequenceId !== thisSequenceId) return; 

            writeLog(`[SEQUENZA] Stoppo il worker ${alias}...`);
            botStopped[alias] = true;
            safeStopBot(alias);
        }, delay);
    });
}

function startWorkerBotsSequentially() {
    if (!isScannerModeEnabled) { writeLog('[TRIGGER] Modalità Scanner disattivata. Ignoro.'); return; }
    if (!canTriggerMassLogin) { writeLog('[TRIGGER] Cooldown attivo. Ignoro.'); return; }
    
    cancelSequentialQuit(); 
    writeLog('[SEQUENZA] Interrompo azioni precedenti e avvio join dei worker...');

    writeLog('[SEQUENZA] Interrompo azioni precedenti e avvio join dei worker...');
    currentSequenceId++; 
    const thisSequenceId = currentSequenceId;

    sendTG('🚀 **Segnale di Ingresso Rilevato!** Avvio dei bot worker...');
    canTriggerMassLogin = false;

    const workerBots = botConfigs.filter(cfg => cfg.alias !== SCANNER_BOT_ALIAS);
    workerBots.sort(() => 0.5 - Math.random()).forEach((config, i) => {
        const delay = i * RECONNECTION_STAGGER_MS + Math.random() * 2000;
        setTimeout(() => {
            if (currentSequenceId !== thisSequenceId) return; 

            const alias = config.alias;
            delete botStopped[alias];
            delete restartAttempts[alias];
            if (botMap[alias]) safeStopBot(alias);
            createBedrockBot(config, 0);
        }, delay);
    });

    setTimeout(() => { writeLog('[TRIGGER] Cooldown terminato.'); canTriggerMassLogin = true; }, 600000);
}



function safeStopBot(alias) {
    const bot = botMap[alias];
    if (!bot) return;

    
    if (bot._watchdog) clearInterval(bot._watchdog);
    if (bot._heartbeat) clearInterval(bot._heartbeat);
    if (bot._tradeLoop) bot._tradeLoop = false;
    if (bot._executorTimer) clearTimeout(bot._executorTimer);
    if (bot._autoTrashTimer) clearTimeout(bot._autoTrashTimer);

    
    Object.values(bot._loops || {}).forEach(clearTimeout);

    
    if (bot.connection) {
        bot.connection.removeAllListeners('packet');
        bot.connection.removeAllListeners('error');
        bot.connection.removeAllListeners('close');
    }

    
    delete bot._watchdog;
    delete bot._heartbeat;
    delete bot._loops;
    delete bot._executorTimer;
    delete bot._lastActivity;
    delete bot._isClaiming;
    delete bot._isLinking;
    delete bot._online;
    delete bot._packetHandler;
    
    
    delete cmdExecutorFlag[alias];
    delete commandQueue[alias];
    
    try {
        bot.removeAllListeners();
        bot.connection?.removeAllListeners();
        bot.close();
    } catch {}
    
    delete botMap[alias];
}


async function createBedrockBot(aliasObj, delay = 0, options = {}) {
    if (delay > 0) await sleep(delay);
    
    const { alias, name, email } = aliasObj;
    if (botStopped[alias] || (botMap[alias] && botMap[alias]._online)) return;

    writeLog(`[START] ${alias} (${email})`);
    if (delay === 0) sendTG(`🟡 Avvio *${alias}* (tentativo ${restartAttempts[alias] || 1})`);

        let client;
        try {
            const clientOptions = {
                username: name,
                offline: false,
                skipPing: true,
                version: '1.21.100'
            };

            
            if (PROXY_ENABLED) {
                writeLog(`[PROXY] ${alias}: Connessione tramite proxy SOCKS5 ${PROXY_SOCKS5_HOST}:${PROXY_SOCKS5_PORT}`);
                
                
                const socksConnection = await new Promise((resolve, reject) => {
                    socks.createConnection({
                        proxy: {
                            host: PROXY_SOCKS5_HOST,
                            port: PROXY_SOCKS5_PORT,
                            type: 5,
                            userId: PROXY_SOCKS5_USERID,
                            password: PROXY_SOCKS5_PASSWORD,
                            timeout: 30000
                        },
                        command: 'connect',
                        destination: {
                            host: HOST,
                            port: PORT
                        },
                        timeout: 30000
                    }, (err, info) => {
                        if (err) return reject(err);
                        resolve(info);
                    });
                });

                
                socksConnection.socket.setKeepAlive(true, 30000);
                socksConnection.socket.setNoDelay(true);
                socksConnection.socket.setTimeout(0);

                
                writeLog(`[SOCKET] ${alias} connected via proxy to ${socksConnection.socket.remoteAddress}:${socksConnection.socket.remotePort}`);

                
                socksConnection.socket.on('close', (hadErr) => writeLog(`[SOCKET] ${alias} close (hadError=${hadErr})`));
                socksConnection.socket.on('end', () => writeLog(`[SOCKET] ${alias} end`));
                socksConnection.socket.on('timeout', () => writeLog(`[SOCKET] ${alias} timeout`));
                socksConnection.socket.on('error', (e) => writeLog(`[SOCKET] ${alias} error: ${e.message}`));

                
                clientOptions.socket = socksConnection.socket;
                
                client = bedrock.createClient(clientOptions);
            } else {
                
                writeLog(`[DIRECT] ${alias}: Connessione diretta a ${HOST}:${PORT}`);
                clientOptions.host = HOST;
                clientOptions.port = PORT;
                client = bedrock.createClient(clientOptions);
            }
        } catch (e) {
            writeLog(`[CRASH SYNC CAUGHT] ${alias}: Errore Fatale SINCRONO durante createClient. ${e.message}`);
            sendTG(`❌ **CRITICO SYNC:** *${alias}* non può avviare il client. Causa: ${e.message}`);
            const setOfflineFunc = () => bindConnectionEvents(alias, {}).setOffline('create_client_error');
            setOfflineFunc();
            return;
        }

        botMap[alias] = client;
        client.alias = alias;
        client.inventory = {};

        client._isLinking = options.isLinking || false;

        setupInventoryContentListener(client);

        client._lastActivity = Date.now();
        
        
        const packetHandler = () => { 
            if (client._online) client._lastActivity = Date.now(); 
        };
        client.on('packet', packetHandler);
        client._packetHandler = packetHandler;

        client._watchdog = setInterval(() => {
            if (!client._online) {
                clearInterval(client._watchdog);
                delete client._watchdog;
                return;
            }
            if (Date.now() - client._lastActivity > 240000) {
                writeLog(`[TIMEOUT] ${alias} inattivo >240s`);
                client.emit('timeout');
            }
        }, 10000);

        bindConnectionEvents(alias, client);

        
        client.on('join', () => {
            writeLog(`[JOIN] ${alias}`);
            sendTG(`✅ *${alias}* connesso`);
            delete restartAttempts[alias];

            
            
            

            
            if (client._isClaiming) {
                setTimeout(() => {
                    if (!client._online) return;
                    
                    
                    setTimeout(() => {
                        if (!client._online) return;
                        triggerDailyClaim(client, alias); 
                    }, 5000);
                }, 23000);

                
                setTimeout(() => {
                    sendTG(`👋 Sequenza di claim per *${alias}* terminata. Disconnessione.`);
                    safeStopBot(alias);
                }, 45000); 
            }
            
            else if (client._isLinking) {
                setTimeout(() => {
                    if (!client._online) return;
                    
                }, 23000);
                setTimeout(() => {
                    writeLog(`[LINKING] ${alias} è in modalità linking. Invio comando /link...`);
                    if (client._online) immediateCommand(alias, '/link');
                }, 28000);
            }
            
            else {
                setTimeout(() => {
                    if (!client._online) return;
                    
                }, 23000);
                setTimeout(() => {
                    if (!client._online) return;
                    
                    startCommandExecutor(alias, client);
                    startAutoTrashLoop(alias, client);
                }, 5000 + Math.random() * 10000);
            }
        });

        client.on('text', (packet) => {
            const strippedMessage = packet.message?.trim().replace(/(&|§|\u00A7)[0-9a-fk-or]/gi, '');
            if (!strippedMessage) return;

            if (client._isLinking) {
                const linkCodeRegex = /Your link code is (\d{4,})\./;
                const match = strippedMessage.match(linkCodeRegex);

                if (match && match[1]) {
                    const code = match[1];
                    const botName = client.username;
                    writeLog(`[LINKING] Codice trovato per ${botName}: ${code}`);
                    sendTG(`✅ **Link Code Rilevato:**\n\`${botName}:${code}\``);
                    client._isLinking = false; 
                }
            }

        
        
        

        if (alias === SCANNER_BOT_ALIAS && isScannerModeEnabled) {
            const lowerCaseMessage = strippedMessage.toLowerCase();

            
            if (lowerCaseMessage.includes('global token-all in 1 minute')) {
                
                if (quitSequenceTimeout) clearTimeout(quitSequenceTimeout);

                writeLog('[SEQUENZA] Segnale di ingresso ricevuto. Avvio bot e timer di sicurezza di 3 minuti.');
                sendTG('🚀 **Segnale di Ingresso!** Avvio dei bot e del timer di uscita di sicurezza...');
                
                startWorkerBotsSequentially();
                isQuitPending = true;

                
                quitSequenceTimeout = setTimeout(() => {
                    writeLog('[SEQUENZA] Timeout di sicurezza scaduto. Messaggio di bonus non ricevuto. Avvio disconnessione.');
                    sendTG('⏰ Timeout di sicurezza scaduto. Avvio disconnessione...');
                    
                    
                    if(isQuitPending) {
                        isQuitPending = false;
                        stopWorkerBotsSequentially();
                    }
                }, 180000); 
            }
            
            else if (lowerCaseMessage.includes('all players have received a bonus token')) {
                
                if (isQuitPending) {
                    writeLog('[SEQUENZA] Bonus ricevuto. Avvio disconnessione come programmato.');
                    sendTG('✅ **Bonus Ricevuto!** Avvio disconnessione...');
                    
                    
                    clearTimeout(quitSequenceTimeout);
                    
                    isQuitPending = false; 
                    stopWorkerBotsSequentially(); 
                }
            }
        }
            
            
            const isTradeRequest = new RegExp(`(The player ${TARGET_TRADER_NAME} wants to trade with you|${TARGET_TRADER_NAME} vuole fare uno scambio|Trade request from ${TARGET_TRADER_NAME})`, 'i').test(strippedMessage);
            const isTradeRequest2 = new RegExp(`(The player ${TARGET_TRADER_NAME2} wants to trade with you|${TARGET_TRADER_NAME2} vuole fare uno scambio|Trade request from ${TARGET_TRADER_NAME2})`, 'i').test(strippedMessage);
            if (isTradeRequest) {
                immediateCommand(client.alias, `/trade accept ${TARGET_TRADER_NAME}`);
                const inventoryListener = (invPacket) => {
                    if (["inventory", "armor", "hotbar", "offhand", 0].includes(invPacket.window_id)) {
                        client.once('inventory_content', inventoryListener);
                        return;
                    }
                    handleTradeGUI(client, invPacket.window_id, client.alias);
                };
                client.once('inventory_content', inventoryListener);
            } else if (isTradeRequest2) {
                immediateCommand(client.alias, `/trade accept ${TARGET_TRADER_NAME2}`);
                const inventoryListener = (invPacket) => {
                    if (["inventory", "armor", "hotbar", "offhand", 0].includes(invPacket.window_id)) {
                        client.once('inventory_content', inventoryListener);
                        return;
                    }
                    handleTradeGUI(client, invPacket.window_id, client.alias);
                };
                client.once('inventory_content', inventoryListener);
            }
        });

        client.on('start_game', (packet) => {
            
            client._currentPos = packet.player_position || { x: 0, y: 0, z: 0 };
            client._currentYaw = packet.rotation?.y || 0;
            client._currentPitch = packet.rotation?.x || 0;
            let tick = 0;

            client._heartbeat = setInterval(() => {
                if (!client._online) {
                    clearInterval(client._heartbeat);
                    return;
                }

                
                const yawChange = (Math.random() - 0.5) * 8;
                const pitchChange = (Math.random() - 0.5) * 6;
                client._currentYaw += yawChange;
                client._currentPitch = Math.max(-89, Math.min(89, client._currentPitch + pitchChange));
                while (client._currentYaw > 360) client._currentYaw -= 360;
                while (client._currentYaw < -360) client._currentYaw += 360;

                
                const pitchRad = client._currentPitch * (Math.PI / 180);
                const yawRad = client._currentYaw * (Math.PI / 180);
                const cosPitch = Math.cos(pitchRad);
                const camVecX = -cosPitch * Math.sin(yawRad);
                const camVecY = -Math.sin(pitchRad);
                const camVecZ = cosPitch * Math.cos(yawRad);

                
                const posVariation = {
                    x: client._currentPos.x + (Math.random() - 0.5) * 0.001,
                    y: client._currentPos.y,
                    z: client._currentPos.z + (Math.random() - 0.5) * 0.001
                };

                
                try {
                    client.queue("player_auth_input", {
                        pitch: client._currentPitch,
                        yaw: client._currentYaw,
                        position: posVariation,
                        move_vector: { x: 0, z: 0 },
                        head_yaw: client._currentYaw,
                        input_data: {
                            "_value": 1407374883553280n,
                            sprinting: false,
                            sneaking: false,
                            block_breaking_delay_enabled: true,
                            vertical_collision: true
                        },
                        input_mode: "mouse",
                        play_mode: "screen",
                        interaction_model: "touch",
                        interact_rotation: {
                            x: client._currentPitch,
                            z: client._currentYaw
                        },
                        tick: BigInt(tick++),
                        delta: { x: 0, y: -0.07840000092983246, z: 0 },
                        analogue_move_vector: { x: 0, z: 0 },
                        camera_orientation: { x: camVecX, y: camVecY, z: camVecZ },
                        raw_move_vector: { x: 0, z: 0 }
                    });
                } catch (err) {
                    writeLog(`[ERROR] ${client.alias}: Errore invio player_auth_input: ${err.message}`);
                }
            }, 50);
        });
}






let dailyRewardLastRunDate = ''; 
let isDailySequenceRunning = false;


async function handleDailyReward(client, windowId, alias, sourceItemOverride = null) { 
    const SOURCE_SLOT = 4;
    const DEST_SLOT = 0;

    await sleep(2000);

    try {
        
        const sourceItem = sourceItemOverride || client.inventory[windowId]?.[SOURCE_SLOT];
        
        if (!sourceItem || sourceItem.network_id === 0) { 
            throw new Error(`Nessun oggetto di origine valido trovato.`);
        }

        
        
        
        const takeRequestId = requestId;
        requestId -= 2;
        const takeRequest = {
            "requests": [{
                "request_id": takeRequestId,
                "actions": [{
                    "type_id": "take",
                    "count": 1, 
                    "source": { "slot_type": { "container_id": "container" }, "slot": SOURCE_SLOT, "stack_id": sourceItem.stack_id },
                    "destination": { "slot_type": { "container_id": "cursor" }, "slot": 0, "stack_id": 0 }
                }], "custom_names": [], "cause": -1
            }]
        };
        client.queue('item_stack_request', takeRequest);

        
        
        
        const responsePacket = await new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                client.removeListener('item_stack_response', listener);
                reject(new Error(`Timeout in attesa della risposta TAKE per request_id ${takeRequestId}`));
            }, 7000);

            const listener = (packet) => {
                const res = packet.responses.find(r => r.request_id === takeRequestId);
                if (res) { clearTimeout(timeout); client.removeListener('item_stack_response', listener); resolve(packet); }
            };
            client.on('item_stack_response', listener);
        });

        const matchingResponse = responsePacket.responses.find(r => r.request_id === takeRequestId);
        if (matchingResponse?.status !== 'ok') throw new Error(`Richiesta TAKE fallita. Status: ${matchingResponse?.status}`);
        
        const cursorEntry = matchingResponse.containers?.find(c => c.slot_type.container_id === 'cursor');
        if (!cursorEntry?.slots?.[0]) throw new Error("Oggetto non trovato sul cursore dopo l'operazione TAKE.");
        
        const newItemStackId = cursorEntry.slots[0].item_stack_id;

        
        
        
        const placeRequestId = requestId;
        requestId -= 2;
        const placeRequest = {
            "requests": [{
                "request_id": placeRequestId,
                "actions": [{
                    "type_id": "place",
                    "count": 1, 
                    "source": { "slot_type": { "container_id": "cursor" }, "slot": 0, "stack_id": newItemStackId },
                    "destination": { "slot_type": { "container_id": "container" }, "slot": DEST_SLOT, "stack_id": 0 }
                }], "custom_names": [], "cause": -1
            }]
        };
        client.queue('item_stack_request', placeRequest);
        await sleep(1000);


        writeLog(`[DAILY] ${alias}: Oggetto spostato con successo da slot ${SOURCE_SLOT} a ${DEST_SLOT}.`);
        sendTG(`🎁 *${alias}:* Premio giornaliero riscosso!`);
        client.queue('container_close', { window_id: windowId, server: false });
        return true; 

    } catch (err) {
        writeLog(`[FATAL DAILY ERROR] ${alias}: ${err.message}`);
        sendTG(`❌ *${alias}:* Errore durante la riscossione del premio giornaliero.`);
        client.queue('container_close', { window_id: windowId, server: false });
        return false; 
    }
    
}


async function trashPotions(client, alias) {
    writeLog(`[TRASH] ${alias}: Avvio procedura di eliminazione pozioni.`);
    
    
    await sleep(2000);
    
    const playerInventory = client.inventory?.inventory || [];
    const potionSlots = [];

    for (let i = 0; i < playerInventory.length; i++) {
        const item = playerInventory[i];
        if (item && item.network_id === POTION_NETWORK_ID) {
            potionSlots.push({
                slot: i,
                count: item.count,
                stack_id: item.stack_id
            });
        }
    }

    if (potionSlots.length === 0) {
        writeLog(`[TRASH] ${alias}: Nessuna pozione trovata da eliminare.`);
        return;
    }

    writeLog(`[TRASH] ${alias}: Trovati ${potionSlots.length} slot con pozioni. Eseguo /trash...`);
    sendTG(`🗑️ *${alias}:* Trovate ${potionSlots.length} pozioni, avvio eliminazione...`);

    let trashWindowId;
    try {
        
        trashWindowId = await new Promise((resolve, reject) => {
            const safetyTimeout = setTimeout(() => {
                client.removeListener('inventory_content', listener);
                reject(new Error('Timeout: la GUI di /trash non si è aperta.'));
            }, 15000); 

            const listener = (packet) => {
                
                if (["inventory", "armor", "hotbar", "offhand", 0].includes(packet.window_id)) {
                    return;
                }
                
                
                if (typeof packet.window_id === 'number' || typeof packet.window_id === 'string') {
                    clearTimeout(safetyTimeout);
                    client.removeListener('inventory_content', listener);
                    writeLog(`[TRASH] ${alias}: GUI ricevuta con window_id: ${packet.window_id}`);
                    resolve(packet.window_id);
                }
            };
            
            client.on('inventory_content', listener);
            immediateCommand(alias, '/trash');
        });

        writeLog(`[TRASH] ${alias}: GUI /trash aperta (ID: ${trashWindowId}). Attendo la sincronizzazione completa...`);
        
        
        await sleep(3000);
        
        
        if (!client.inventory[trashWindowId]) {
            throw new Error(`Inventario della GUI trash non sincronizzato. Window ID: ${trashWindowId}`);
        }

        let successCount = 0;
        let destinationSlot = 0;
        
        for (const potionData of potionSlots) {
            try {
                const slot = potionData.slot;
                
                
                const currentItem = client.inventory.inventory?.[slot];
                if (!currentItem || currentItem.network_id !== POTION_NETWORK_ID || !currentItem.stack_id) {
                    writeLog(`[TRASH WARNING] ${alias}: Oggetto nello slot ${slot} non più valido o già spostato. Salto.`);
                    continue;
                }

                
                let sourceContainerId;
                if (slot >= 0 && slot <= 8) {
                    sourceContainerId = 'hotbar';
                } else if (slot >= 9 && slot <= 35) {
                    sourceContainerId = 'inventory';
                } else {
                    writeLog(`[TRASH WARNING] ${alias}: Slot ${slot} fuori range, salto.`);
                    continue;
                }

                
                const takeRequestId = requestId;
                requestId -= 2;
                
                const takeRequest = {
                    requests: [{
                        request_id: takeRequestId,
                        actions: [{
                            type_id: 'take',
                            count: currentItem.count,
                            source: {
                                slot_type: { container_id: sourceContainerId },
                                slot: slot,
                                stack_id: currentItem.stack_id
                            },
                            destination: {
                                slot_type: { container_id: 'cursor' },
                                slot: 0,
                                stack_id: 0
                            }
                        }],
                        custom_names: [],
                        cause: -1
                    }]
                };
                
                client.queue('item_stack_request', takeRequest);

                
                const responseTakePacket = await new Promise((resolve, reject) => {
                    const timeout = setTimeout(() => {
                        client.removeListener('item_stack_response', listener);
                        reject(new Error(`Timeout risposta TAKE (Req ID: ${takeRequestId})`));
                    }, 7000);
                    
                    const listener = (packet) => {
                        const matchingResponse = packet.responses.find(r => r.request_id === takeRequestId);
                        if (matchingResponse) {
                            clearTimeout(timeout);
                            client.removeListener('item_stack_response', listener);
                            resolve(packet);
                        }
                    };
                    
                    client.on('item_stack_response', listener);
                });

                const takeResponse = responseTakePacket.responses.find(r => r.request_id === takeRequestId);
                if (takeResponse?.status !== 'ok') {
                    throw new Error(`Richiesta TAKE fallita. Status: ${takeResponse?.status || 'unknown'}`);
                }

                
                const cursorEntry = takeResponse.containers?.find(c => c.slot_type.container_id === 'cursor');
                if (!cursorEntry?.slots?.[0]?.item_stack_id) {
                    throw new Error("Item non trovato sul cursore dopo il TAKE.");
                }

                const newStackId = cursorEntry.slots[0].item_stack_id;

                
                const placeRequestId = requestId;
                requestId -= 2;
                
                const placeRequest = {
                    requests: [{
                        request_id: placeRequestId,
                        actions: [{
                            type_id: 'place',
                            count: currentItem.count,
                            source: {
                                slot_type: { container_id: 'cursor' },
                                slot: 0,
                                stack_id: newStackId
                            },
                            destination: {
                                slot_type: { container_id: 'container' },
                                slot: destinationSlot,
                                stack_id: 0
                            }
                        }],
                        custom_names: [],
                        cause: -1
                    }]
                };
                
                client.queue('item_stack_request', placeRequest);

                
                await new Promise((resolve, reject) => {
                    const timeout = setTimeout(() => {
                        client.removeListener('item_stack_response', listener);
                        reject(new Error(`Timeout risposta PLACE (Req ID: ${placeRequestId})`));
                    }, 7000);
                    
                    const listener = (packet) => {
                        const placeResponse = packet.responses.find(r => r.request_id === placeRequestId);
                        if (placeResponse) {
                            clearTimeout(timeout);
                            client.removeListener('item_stack_response', listener);
                            
                            if (placeResponse.status === 'ok') {
                                resolve(packet);
                            } else {
                                reject(new Error(`Richiesta PLACE fallita. Status: ${placeResponse.status}`));
                            }
                        }
                    };
                    
                    client.on('item_stack_response', listener);
                });

                destinationSlot++;
                successCount++;
                writeLog(`[TRASH] ${alias}: Pozione spostata con successo dallo slot ${slot} -> trash slot ${destinationSlot - 1}`);
                
                
                await sleep(500);

            } catch (err) {
                writeLog(`[TRASH ERROR] ${alias}: Fallito il trasferimento di un item dallo slot ${potionData.slot}. Causa: ${err.message}`);
                
                await sleep(1000);
            }
        }

        writeLog(`[TRASH] ${alias}: Trasferimento completato. ${successCount}/${potionSlots.length} pozioni eliminate.`);
        
        if (successCount > 0) {
            sendTG(`✅ *${alias}:* ${successCount} pozioni eliminate con successo.`);
        } else {
            sendTG(`⚠️ *${alias}:* Nessuna pozione è stata eliminata.`);
        }
        
        
        await sleep(1500);
        client.queue('container_close', { window_id: trashWindowId, server: false });

    } catch (err) {
        writeLog(`[TRASH FATAL ERROR] ${alias}: La procedura è fallita completamente. Causa: ${err.stack || err.message}`);
        sendTG(`❌ *${alias}:* Errore critico durante l'eliminazione delle pozioni: ${err.message}`);
        
        
        if (trashWindowId) {
            try {
                client.queue('container_close', { window_id: trashWindowId, server: false });
            } catch {}
        }
    }
}


async function trashUnwantedItems(client, alias) {
    writeLog(`[TRASH ITEMS] ${alias}: Avvio procedura di eliminazione item non necessari.`);
    
    await sleep(2000);
    
    const playerInventory = client.inventory?.inventory || [];
    const unwantedSlots = [];

    for (let i = 0; i < playerInventory.length; i++) {
        const item = playerInventory[i];
        if (item && item.network_id !== 0) {
            
            if (item.network_id !== TOKEN_ITEM_NETWORK_ID && 
                item.network_id !== KEY_ITEM_NETWORK_ID && 
                item.network_id !== HOTDOG_ITEM_NETWORK_ID) {
                unwantedSlots.push({
                    slot: i,
                    count: item.count,
                    stack_id: item.stack_id,
                    network_id: item.network_id
                });
            }
        }
    }

    if (unwantedSlots.length === 0) {
        writeLog(`[TRASH ITEMS] ${alias}: Nessun item non necessario trovato.`);
        return;
    }

    writeLog(`[TRASH ITEMS] ${alias}: Trovati ${unwantedSlots.length} slot con item da eliminare. Eseguo /trash...`);
    sendTG(`🗑️ *${alias}:* Trovati ${unwantedSlots.length} item non necessari, avvio eliminazione...`);

    let trashWindowId;
    try {
        trashWindowId = await new Promise((resolve, reject) => {
            const safetyTimeout = setTimeout(() => {
                reject(new Error('Timeout: GUI /trash non ricevuta in 15 secondi.'));
            }, 15000);

            const listener = (packet) => {
                if (packet.window_id && packet.window_id !== 0 && packet.window_id !== 'inventory') {
                    clearTimeout(safetyTimeout);
                    client.removeListener('inventory_content', listener);
                    
                    if (!client.inventory[packet.window_id]) {
                        client.inventory[packet.window_id] = packet.input;
                    }
                    
                    resolve(packet.window_id);
                }
            };
            
            client.on('inventory_content', listener);
            immediateCommand(alias, '/trash');
        });

        writeLog(`[TRASH ITEMS] ${alias}: GUI /trash aperta (ID: ${trashWindowId}). Attendo sincronizzazione...`);
        
        await sleep(3000);
        
        if (!client.inventory[trashWindowId]) {
            throw new Error(`Inventario della GUI trash non sincronizzato. Window ID: ${trashWindowId}`);
        }

        let successCount = 0;
        let destinationSlot = 0;
        
        for (const itemData of unwantedSlots) {
            try {
                let sourceContainerId;
                if (itemData.slot >= 0 && itemData.slot <= 8) {
                    sourceContainerId = 'hotbar';
                } else if (itemData.slot >= 9 && itemData.slot <= 35) {
                    sourceContainerId = 'inventory';
                } else {
                    sourceContainerId = 'inventory';
                }

                const takeRequestId = requestId;
                requestId -= 2;
                const takeRequest = {
                    "requests": [{
                        "request_id": takeRequestId,
                        "actions": [{
                            "type_id": "take",
                            "count": itemData.count,
                            "source": {
                                "slot_type": { "container_id": sourceContainerId },
                                "slot": itemData.slot,
                                "stack_id": itemData.stack_id
                            },
                            "destination": {
                                "slot_type": { "container_id": "cursor" },
                                "slot": 0,
                                "stack_id": 0
                            }
                        }],
                        "custom_names": [],
                        "cause": -1
                    }]
                };
                client.queue('item_stack_request', takeRequest);

                const responsePacket = await new Promise((resolve, reject) => {
                    const timeout = setTimeout(() => {
                        reject(new Error(`Timeout TAKE per slot ${itemData.slot}`));
                    }, 5000);

                    const listener = (packet) => {
                        if (packet.responses && packet.responses.some(r => r.request_id === takeRequestId)) {
                            clearTimeout(timeout);
                            client.removeListener('item_stack_response', listener);
                            resolve(packet);
                        }
                    };
                    client.on('item_stack_response', listener);
                });

                const matchingResponse = responsePacket.responses.find(r => r.request_id === takeRequestId);
                if (!matchingResponse || matchingResponse.status !== 'ok') {
                    throw new Error(`TAKE fallito. Status: ${matchingResponse?.status}`);
                }

                const cursorEntry = matchingResponse.containers?.find(c => c.slot_type.container_id === 'cursor');
                if (!cursorEntry?.slots?.[0]) {
                    throw new Error("Item non trovato sul cursore dopo TAKE.");
                }

                const newStackId = cursorEntry.slots[0].item_stack_id;

                const placeRequestId = requestId;
                requestId -= 2;
                const placeRequest = {
                    "requests": [{
                        "request_id": placeRequestId,
                        "actions": [{
                            "type_id": "place",
                            "count": itemData.count,
                            "source": {
                                "slot_type": { "container_id": "cursor" },
                                "slot": 0,
                                "stack_id": newStackId
                            },
                            "destination": {
                                "slot_type": { "container_id": "container" },
                                "slot": destinationSlot,
                                "stack_id": 0
                            }
                        }],
                        "custom_names": [],
                        "cause": -1
                    }]
                };
                client.queue('item_stack_request', placeRequest);

                await sleep(500);
                destinationSlot++;
                successCount++;

            } catch (err) {
                writeLog(`[TRASH ITEMS ERROR] ${alias}: Errore trasferimento slot ${itemData.slot} (ID: ${itemData.network_id}): ${err.message}`);
            }
        }

        writeLog(`[TRASH ITEMS] ${alias}: Trasferimento completato. ${successCount}/${unwantedSlots.length} item eliminati.`);
        
        if (successCount > 0) {
            sendTG(`✅ *${alias}:* ${successCount} item non necessari eliminati con successo.`);
        } else {
            sendTG(`⚠️ *${alias}:* Nessun item è stato eliminato.`);
        }
        
        await sleep(1500);
        client.queue('container_close', { window_id: trashWindowId, server: false });

    } catch (err) {
        writeLog(`[TRASH ITEMS FATAL ERROR] ${alias}: Procedura fallita. Causa: ${err.stack || err.message}`);
        sendTG(`❌ *${alias}:* Errore critico durante l'eliminazione degli item: ${err.message}`);
        
        if (trashWindowId) {
            try {
                client.queue('container_close', { window_id: trashWindowId, server: false });
            } catch {}
        }
    }
}





function executeFullDailySequence() {
    if (isDailySequenceRunning) {
        writeLog('[DAILY SEQUENCE] Ignorato: una sequenza è già in corso.');
        sendTG('⚠️ Una sequenza di riscossione è già in corso. Attendi il suo completamento.');
        return;
    }
    
    
    
    dailyState.lastRun = Date.now();
    saveDailyState();
    writeLog(`[SCHEDULER] Esecuzione giornaliera avviata. Prossimo claim possibile dopo ${new Date(dailyState.lastRun + 24 * 60 * 60 * 1000).toLocaleString()}`);
    

    isDailySequenceRunning = true;
    
    writeLog('[DAILY SEQUENCE] Avvio sequenza completa: LOGIN -> CLAIM -> LOGOUT.');
    sendTG('⚙️ **Avvio sequenza premio giornaliero...**');

    
    startWorkerBotsSequentially();

    const loginWaitTime = (botConfigs.length * RECONNECTION_STAGGER_MS) + 60000;
    writeLog(`[DAILY SEQUENCE] In attesa di ${Math.round(loginWaitTime / 1000)}s per il login dei bot...`);
    
    setTimeout(() => {
        writeLog('[DAILY SEQUENCE] Fase di riscossione premio avviata.');
        sendTG('💰 Inizio riscossione premi per i bot connessi...');
        
        const onlineBots = Object.keys(botMap).filter(alias => botMap[alias]?._online && alias !== SCANNER_BOT_ALIAS);
        if (onlineBots.length === 0) {
            writeLog('[DAILY SEQUENCE] Nessun bot worker si è connesso. Sequenza terminata.');
            sendTG('⚠️ Nessun bot worker online. La riscossione è saltata.');
            isDailySequenceRunning = false; 
            return;
        }
        onlineBots.forEach((alias, index) => {
            
            const claimDelay = index * 20000;
            setTimeout(() => {
                const client = botMap[alias];
                if (!client?._online) return;

                triggerDailyClaim(client, alias);
            
            }, claimDelay);
        });
        const logoutWaitTime = (onlineBots.length * 5000) + 20000;
        writeLog(`[DAILY SEQUENCE] In attesa di ${Math.round(logoutWaitTime / 1000)}s per il logout...`);

        setTimeout(() => {
            writeLog('[DAILY SEQUENCE] Fase di logout avviata.');
            sendTG('👋 Riscossione completata. Disconnessione dei bot worker...');
            stopWorkerBotsSequentially();

            
            setTimeout(() => {
                 isDailySequenceRunning = false; 
                 writeLog('[DAILY SEQUENCE] Sequenza completata. Flag resettato.');
                 sendTG('✅ **Sequenza giornaliera completata.**');
            }, 20000); 

        }, logoutWaitTime);

    }, loginWaitTime);
}




function setupDailyScheduler() {
    writeLog('[SCHEDULER] Pianificatore per sequenza giornaliera attivato.');

    const checkAndRun = () => {
        
        if (!isScannerModeEnabled) return;

        const now = Date.now();
        const twentyFourHoursAndOneMinute = (24 * 60 * 60 * 1000) + (60 * 1000); 

        
        if (now > dailyState.lastRun + twentyFourHoursAndOneMinute) {
            writeLog('[SCHEDULER] È ora di eseguire il claim giornaliero automatico.');
            executeFullDailySequence();
        }
    };

    
    setInterval(checkAndRun, 60000); 
}



function bindConnectionEvents(alias, client) {
    const setOffline = (why) => {
        if (!client._online) return;

        client._online = false;
        writeLog(`[OFFLINE] ${alias}: ${why}`);
        safeStopBot(alias);

        if (botStopped[alias]) return;

        
        if (isScannerModeEnabled && alias !== SCANNER_BOT_ALIAS) {
            writeLog(`[RETRY] ${alias} è un worker in modalità Scanner. Non si riconnetterà automaticamente.`);
            return;
        }

        
        restartAttempts[alias] = (restartAttempts[alias] || 0) + 1;
        const attempts = restartAttempts[alias];
        writeLog(`[RETRY] ${alias} - Tentativo di riconnessione numero ${attempts}/${MAX_RETRY_ATTEMPTS}.`);

        if (attempts > MAX_RETRY_ATTEMPTS) {
            writeLog(`[FATAL] ${alias} ha superato ${MAX_RETRY_ATTEMPTS} tentativi. Stop permanente.`);
            sendTG(`❌ **CRITICO:** *${alias}* ha fallito il riavvio per ${MAX_RETRY_ATTEMPTS} volte.`);
            botStopped[alias] = true;
            return;
        }

        if (!reconnectionQueue.includes(alias)) {
            writeLog(`[QUEUE] ${alias} aggiunto alla coda di riconnessione.`);
            reconnectionQueue.push(alias);
            clearTimeout(reconnectionQueueTimer);
            reconnectionQueueTimer = setTimeout(processReconnectionQueue, 5000);
        }
    };

    client._online = true;
    client.on('close', () => setOffline('close'));
    client.on('kick', (reason) => setOffline(`kick: ${reason?.message}`));
    client.on('error', e => setOffline(`error: ${e.message}`));
    client.on('timeout', () => setOffline('timeout'));

    return { setOffline };
}






telegramBot?.on('message', msg => {
    if (TELEGRAM_CHAT_ID && String(msg.chat.id) !== TELEGRAM_CHAT_ID) {
        writeLog(`[Security] Comando ignorato da chat ID non autorizzato: ${msg.chat.id}`);
        return;
    }
    const text = msg.text?.trim();
    if (!text) return;
    let [command, ...rest] = text.split(/\s+/);
    command = command.split('@')[0];
    const arg = rest.join(' ').toLowerCase();

    switch (command) {
        case '/claimone': {
            const alias = arg;
            if (!alias) return sendTG('Usa: `/claimone <alias>`');
            const cfg = botConfigs.find(o => o.alias === alias);
            if (!cfg) return sendTG(`⚠️ Bot non trovato: ${alias}`);

            const client = botMap[alias];
            if (client?._online) {
                triggerDailyClaim(client, alias);
            } else {
                sendTG(`⚙️ Avvio sequenza di claim per il worker *${alias}*... (Login -> Claim -> Logout)`);
                if (botMap[alias]) safeStopBot(alias);
                createBedrockBot(cfg, 1000, { isClaiming: true });
            }
            return;
        }
        case '/getlink': {
            const alias = arg;
            if (!alias) return sendTG('Usa: /getlink <alias>');
            const cfg = botConfigs.find(o => o.alias === alias);
            if (!cfg) return sendTG(`⚠️ Bot non trovato: ${alias}`);

            sendTG(`🔗 Avvio linking manuale per *${alias}*...`);

            
            if (botMap[alias]) safeStopBot(alias);

            
            createBedrockBot(cfg, 1000, { isLinking: true });

            
            setTimeout(() => {
                if (botMap[alias] && botMap[alias]._isLinking) {
                    sendTG(`⏰ Tempo scaduto. Stoppo *${alias}*. Se non hai ricevuto il codice, riprova.`);
                    safeStopBot(alias);

                    
                    if (alias === SCANNER_BOT_ALIAS) {
                        sendTG(`🤖 Riavvio lo scanner *${alias}* in modalità normale.`);
                        createBedrockBot(cfg, 5000);
                    }
                }
            }, 90000); 
            return;
        }

        case '/link': { 
            reply(msg, 'ℹ️ Usa <b>/linkstart</b> per avviare la procedura o <b>/linkstop</b> per terminarla.');
            return;
        }

        case '/linkstart': {
            if (linkingBots.size > 0) {
                return sendTG('⚠️ Una sessione di linking è già attiva. Usa prima `/linkstop`.');
            }
            sendTG('🚀 **Avvio sequenza di linking...** I bot entreranno uno alla volta (lo scanner verrà saltato).');

            botConfigs.forEach((config, i) => {
                const alias = config.alias;

                
                if (alias === SCANNER_BOT_ALIAS) {
                    writeLog(`[LINKING] Lo scanner ${alias} viene saltato.`);
                    return; 
                }

                linkingBots.add(alias); 

                const delay = i * RECONNECTION_STAGGER_MS + Math.random() * 500;
                
                
                setTimeout(() => {
                    
                    if (!linkingBots.has(alias)) return;
                    
                    delete botStopped[alias];
                    delete restartAttempts[alias];
                    if (botMap[alias]) safeStopBot(alias);
                    createBedrockBot(config, 0, { isLinking: true });
                }, delay);
            });
            return;
        }

        case '/linkstop': {
            if (linkingBots.size === 0) {
                return sendTG('ℹ️ Nessuna sessione di linking attiva da fermare.');
            }
            sendTG('👋 **Avvio disconnessione sequenziale...**');
            
            let i = 0;
            linkingBots.forEach(alias => {
                const delay = i * 2000; 
                setTimeout(() => {
                    writeLog(`[LINKING] Stoppo il bot ${alias}...`);
                    safeStopBot(alias);
                }, delay);
                i++;
            });

            linkingBots.clear(); 
            sendTG('✅ Tutti i bot della sessione di linking sono stati disconnessi.');
            return;
        }
        case '/claim': {
            if (!isScannerModeEnabled) {
                return sendTG('⚠️ Il comando `/claim` è utilizzabile solo quando la `togglemode` (modalità scanner) è attiva.');
            }
            
            dailyRewardLastRunDate = new Date().toISOString().slice(0, 10);
            executeFullDailySequence();
            return;
        }
        case '/trashitems': {
            const alias = arg;
            if (!alias) {
                
                const onlineBots = Object.keys(botMap).filter(a => botMap[a]?._online);
                if (onlineBots.length === 0) return sendTG('⚠️ Nessun bot online.');
                
                sendTG(`🗑️ Avvio pulizia item per ${onlineBots.length} bot...`);
                onlineBots.forEach((botAlias, index) => {
                    setTimeout(() => {
                        const client = botMap[botAlias];
                        if (client?._online) {
                            trashUnwantedItems(client, botAlias);
                        }
                    }, index * 15000); 
                });
                return;
            }
            
            
            const client = botMap[alias];
            if (!client?._online) return sendTG(`⚠️ *${alias}* non è online.`);
            
            sendTG(`🗑️ Avvio pulizia item per *${alias}*...`);
            trashUnwantedItems(client, alias);
            return;
        }
        case '/togglemode': {
            isScannerModeEnabled = !isScannerModeEnabled;
            const stato = isScannerModeEnabled ? "MODALITÀ SCANNER ATTIVATA" : "MODALITÀ CONTINUA ATTIVATA";
            sendTG(`✅ **${stato}**`);
            if (isScannerModeEnabled) {
                writeLog('[MODALITÀ] Passaggio a Modalità Scanner. Fermo i worker e avvio lo scanner...');
                stopWorkerBotsSequentially();
                
                const scanner = botConfigs.find(cfg => cfg.alias === SCANNER_BOT_ALIAS);
                if (scanner && !botMap[SCANNER_BOT_ALIAS]) {
                    createBedrockBot(scanner, 0);
                }
            } else {
                writeLog('[MODALITÀ] Passaggio a Modalità Continua. Avvio tutti i bot...');
                startAllBotsSequentially();
            }
            return;
        }
        case '/addaccount': {
            const [alias, email] = (arg || '').split(',').map(s => s.trim());
            if (!alias || !email) return sendTG('Formato: /addaccount alias,email');
            if (botConfigs.find(o => o.alias === alias)) return sendTG(`⚠️ Alias *${alias}* già esistente.`);
            botConfigs.push({ alias: alias, name: alias.toUpperCase(), email });
            fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(botConfigs, null, 2));
            return sendTG(`✅ Account aggiunto: *${alias}*`);
        }

        case '/start':
        case '/restart': {
            if (!arg) return sendTG('Uso: /start alias');
            const cfg = botConfigs.find(o => o.alias === arg);
            if (!cfg) return sendTG(`⚠️ Bot non trovato: ${arg}`);
            delete botStopped[arg];
            delete restartAttempts[arg];
            if (botMap[arg]) safeStopBot(arg);
            createBedrockBot(cfg, 0);
            return sendTG(`✅ *${arg}* avviato/riavviato`);
        }
        case '/stop': {
            if (!arg) return sendTG('Uso: /stop alias');
            botStopped[arg] = true;
            safeStopBot(arg);
            return sendTG(`⛔ *${arg}* stoppato`);
        }
        case '/allstop': {
            Object.keys(botMap).forEach(a => {
                safeStopBot(a);
                botStopped[a] = true;
            });
            return sendTG('🛑 Tutti i bot stoppati');
        }
        
        case '/status': {
            if (botConfigs.length === 0) return reply(msg, '❗ Nessun bot configurato.');
            
            const statuses = botConfigs.map(({ alias }) => {
                const client = botMap[alias];
                const online = client?._online;
                
                let statusText = online ? '🟢 Online' : '🔴 Offline';
                
                
                if (online) {
                    const tokens = countInventoryTokens(client);
                    const keys = countInventoryKeys(client);
                    const hotdogs = countInventoryHotdogs(client);
                    statusText += ` | Token: <b>${tokens.toLocaleString('it-IT')}</b>`;
                    statusText += ` | Key: <b>${keys.toLocaleString('it-IT')}</b>`;
                    statusText += ` | Hotdog: <b>${hotdogs.toLocaleString('it-IT')}</b>`;
                }

                return `<b>${alias}</b>: ${statusText}`;
            }).join('\n');
            
            return reply(msg, `📋 Stato dei bot:\n\n${statuses}`);
        }
    }
});




async function triggerDailyClaim(client, alias) { 
    if (!client?._online) {
        writeLog(`[CLAIM] Tentativo di claim fallito per ${alias} (offline).`);
        return;
    }

    writeLog(`[CLAIM] ${alias} avvia la procedura di riscossione premio...`);
    sendTG(`💰 Avvio riscossione per *${alias}*...`);
    
    let claimSuccessful = false; 

    const slotListener = async (packet) => { 
        if (packet.window_id === 'first' && packet.slot === 4 && packet.item?.network_id !== 0) {
            
            writeLog(`[CLAIM] ${alias}: BINGO! Rilevato oggetto premio nello slot 4 della GUI 'first'.`);
            cleanup();

            
            claimSuccessful = await handleDailyReward(client, packet.window_id, alias, packet.item);

            
            if (claimSuccessful) {
                trashPotions(client, alias);
            }
        }
    };

    const cleanup = () => {
        client.removeListener('inventory_slot', slotListener);
        if (safetyTimeout) clearTimeout(safetyTimeout);
    };

    const safetyTimeout = setTimeout(() => {
        
        if (!claimSuccessful) {
            writeLog(`[CLAIM ERROR] ${alias}: Timeout. L'oggetto del premio non è apparso nella GUI in 15 secondi.`);
            sendTG(`⚠️ *${alias}*: Timeout durante la riscossione del premio.`);
            cleanup();
        }
    }, 15000);

    client.on('inventory_slot', slotListener);

    immediateCommand(alias, '/daily');
}








if (PROXY_ENABLED) {
    writeLog(`[CONFIG] Proxy SOCKS5 ABILITATO: ${PROXY_SOCKS5_HOST}:${PROXY_SOCKS5_PORT}`);
} else {
    writeLog(`[CONFIG] Connessione DIRETTA (proxy disabilitato)`);
}

if (isScannerModeEnabled) {
    const scannerConfig = botConfigs.find(cfg => cfg.alias === SCANNER_BOT_ALIAS);
    if (scannerConfig) {
        writeLog(`[AVVIO] Modalità Scanner. Avvio di ${SCANNER_BOT_ALIAS}. In attesa del segnale...`);
        createBedrockBot(scannerConfig, 0);
    } else {
        writeLog(`[ERRORE FATALE] Bot scanner "${SCANNER_BOT_ALIAS}" non trovato in accounts.json!`);
        process.exit(1);
    }
} else {
    writeLog("[AVVIO] Modalità Continua. Avvio di tutti i bot in sequenza.");
    startAllBotsSequentially();
}

writeLog('[INIT] Bot Bedrock Protocol avviato con successo!');



try {
    botConfigs = JSON.parse(fs.readFileSync(ACCOUNTS_FILE));
} catch {
    writeLog(`Errore caricando ${path.basename(ACCOUNTS_FILE)}: file non trovato. Inizializzo array vuoto.`);
    botConfigs = [];
    fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(botConfigs, null, 2));
}


loadDailyState();




setupDailyScheduler();


setInterval(() => {
    const mem = process.memoryUsage();
    writeLog(`[MEM] RSS=${(mem.rss/1024/1024).toFixed(1)}MB | Heap=${(mem.heapUsed/1024/1024).toFixed(1)}MB/${(mem.heapTotal/1024/1024).toFixed(1)}MB`);
    
    
    Object.keys(commandQueue).forEach(alias => {
        if (!botMap[alias] || commandQueue[alias]?.length === 0) {
            delete commandQueue[alias];
            delete cmdExecutorFlag[alias];
        }
    });
    
    
    if (global.gc && mem.heapUsed / mem.heapTotal > 0.9) {
        writeLog('[MEM] Heap usage >90%, triggering GC...');
        global.gc();
    }
}, 600000);
