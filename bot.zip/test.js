require('dotenv').config();
const fs = require('fs');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api');
const bedrock = require('bedrock-protocol');

const PROJECT_DIR = path.join(__dirname);
const ACCOUNTS_FILE = path.join(PROJECT_DIR, 'accounts.json');
const LOG_DIR = path.join(__dirname, 'logs');
const HOST = process.env.HOST;
const PORT = parseInt(process.env.PORT);
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || '';
const MAX_RETRY_ATTEMPTS = 5;
const BASE_RETRY_DELAY = 60000;
const RECONNECTION_STAGGER_MS = 6500;
const TARGET_TRADER_NAME = process.env.TARGET_TRADER_NAME || 'X_MITO_X';
const TARGET_TRADER_NAME2 = process.env.TARGET_TRADER_NAME2 || 'CPlusPluss';
const SCANNER_BOT_ALIAS = process.env.SCANNER || '';
const TOKEN_ITEM_NETWORK_ID = 551; 
const POTION_NETWORK_ID = 453;
const KEY_ITEM_NETWORK_ID = 131;
const HOTDOG_ITEM_NETWORK_ID = -967;

let canTriggerMassLogin = true;
let isScannerModeEnabled = true;
const DAILY_STATE_FILE = path.join(PROJECT_DIR, 'daily_state.json');
const botMap = {};
const botStopped = {};
const restartAttempts = {};
let reconnectionQueue = [];
let reconnectionQueueTimer = null;
const commandQueue = {};
const cmdExecutorFlag = {};
let requestId = -27;
let botConfigs;
let currentSequenceId = 0; 
const linkingBots = new Set();
let dailyState = { lastRun: 0 };
let quitSequenceTimeout = null;
let isQuitPending = false;

process.on('unhandledRejection', (reason, promise) => {
    writeLog(`[CRASH FATALE - UNHANDLED REJECTION] RAGIONE: ${reason?.stack || reason}`);
    sendTG(`⚠️ **ATTENZIONE:** Rifiuto Promise non gestito! Avvio riavvio coordinato di tutti i bot.`);
    botConfigs.forEach(cfg => {
        const alias = cfg.alias;
        if (!botStopped[alias] && !reconnectionQueue.includes(alias)) {
            const client = botMap[alias];
            if (client?._online) {
                client.emit('error', new Error('Recovery da Unhandled Rejection'));
            } else {
                reconnectionQueue.push(alias);
                writeLog(`[RECOVERY] ${alias} aggiunto alla coda dopo unhandled rejection`);
            }
        }
    });
});

process.on('uncaughtException', (error) => {
    writeLog(`[CRASH FATALE - UNCAUGHT EXCEPTION] RAGIONE: ${error.stack || error}`);
    sendTG(`🚨 **CRITICO:** Crash sincrono! Il processo è stato terminato. Controllare i log. Causa: ${error.message.substring(0, 100)}...`);
    process.exit(1); 
});

try {
    botConfigs = JSON.parse(fs.readFileSync(ACCOUNTS_FILE));
} catch {
    writeLog(`Errore caricando ${path.basename(ACCOUNTS_FILE)}: file non trovato. Inizializzo array vuoto.`);
    botConfigs = [];
    fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(botConfigs, null, 2));
}

if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
const dayStamp = new Date().toISOString().slice(0, 10).replace(/-/g, '_');
const logStream = fs.createWriteStream(path.join(LOG_DIR, `bedrock_afk_${dayStamp}.log`), { flags: 'a' });
const telegramBot = TELEGRAM_BOT_TOKEN ? new TelegramBot(TELEGRAM_BOT_TOKEN, { polling: true }) : null;

function writeLog(msg) {
    const entry = `[${new Date().toISOString()}] ${msg}`;
    console.log(entry);
    logStream.write(entry + '\n');
}

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

function cancelSequentialQuit() {
    if (isQuitPending) {
        clearTimeout(quitSequenceTimeout);
        isQuitPending = false;
        writeLog('[SEQUENZA] Uscita annullata a causa di un segnale bonus o di un nuovo comando.');
        sendTG('🎉 **Uscita Annullata!** Rilevato un segnale di token bonus. I bot rimangono online.');
    }
}

function processReconnectionQueue() {
    if (reconnectionQueue.length === 0) return;
    writeLog(`[QUEUE] Elaborazione coda per ${reconnectionQueue.length} bot.`);
    const botsToRestart = [...reconnectionQueue];
    reconnectionQueue = [];
    botsToRestart.sort(() => 0.5 - Math.random());
    botsToRestart.forEach((alias, index) => {
        const cfg = botConfigs.find(o => o.alias === alias);
        if (cfg && !botStopped[alias]) {
            const attempts = restartAttempts[alias] || 1;
            const backoffDelay = BASE_RETRY_DELAY * Math.pow(2, attempts - 1) + Math.random() * 5000;
            const staggerDelay = index * RECONNECTION_STAGGER_MS;
            const totalDelay = staggerDelay + backoffDelay;
            writeLog(`[QUEUE] ${alias} (Tentativo ${attempts}) riavvierà tra ${(totalDelay / 1000).toFixed(1)}s (Stagger: ${staggerDelay/1000}s + Backoff: ${backoffDelay/1000}s)`);
            createBedrockBot(cfg, totalDelay);
        }
    });
    clearTimeout(reconnectionQueueTimer);
    reconnectionQueueTimer = null;
}

function loadDailyState() {
    try {
        if (fs.existsSync(DAILY_STATE_FILE)) {
            const data = fs.readFileSync(DAILY_STATE_FILE, 'utf8');
            dailyState = JSON.parse(data);
            writeLog(`[SCHEDULER] Stato del daily caricato. Ultima esecuzione: ${new Date(dailyState.lastRun).toLocaleString()}`);
        } else {
            writeLog(`[SCHEDULER] File di stato non trovato. Ne verrà creato uno nuovo alla prima esecuzione.`);
            saveDailyState();
        }
    } catch (err) {
        writeLog(`[SCHEDULER ERROR] Impossibile leggere il file di stato: ${err.message}`);
    }
}

function saveDailyState() {
    try {
        fs.writeFileSync(DAILY_STATE_FILE, JSON.stringify(dailyState, null, 2));
    } catch (err) {
        writeLog(`[SCHEDULER ERROR] Impossibile scrivere sul file di stato: ${err.message}`);
    }
}

function sendTG(txt) {
    if (telegramBot && TELEGRAM_CHAT_ID) {
        telegramBot.sendMessage(TELEGRAM_CHAT_ID, txt, { parse_mode: 'Markdown' })
            .catch(err => writeLog(`[Telegram Error] Invio fallito: ${err.code} - ${err.response?.body?.description || err.message}`));
    }
}

function reply(msg, html) {
    telegramBot?.sendMessage(msg.chat.id, html, { parse_mode: 'HTML' })
        .catch(err => writeLog(`[Telegram Error] Risposta fallita: ${err.code} - ${err.response?.body?.description || err.message}`));
}

function queueCommand(alias, cmd) {
    if (!botMap[alias]?._online) return;
    const q = (commandQueue[alias] ||= []);
    q.push(cmd);
    if (q.length > 20) {
        q.splice(0, q.length - 20);
        writeLog(`[QUEUE] ${alias} overflow, shrink.`);
    }
}

function immediateCommand(alias, cmd) {
    const client = botMap[alias];
    if (!client?._online) {
        writeLog(`[CMD FAIL] ${alias}: Offline, non posso inviare comando immediato: ${cmd}`);
        return;
    }
    writeLog(`[EXEC IMMED] ${alias} -> ${cmd}`);
    client.write('text', {
        type: 'chat',
        needs_translation: false,
        source_name: client.username,
        xuid: '',
        platform_chat_id: '',
        filtered_message: '',
        message: cmd
    });
}

function startCommandExecutor(alias, client) {
    if (cmdExecutorFlag[alias]) return;
    cmdExecutorFlag[alias] = true;
    const exec = () => {
        if (!client._online) {
            cmdExecutorFlag[alias] = false;
            clearTimeout(client._executorTimer);
            return;
        }
        const q = commandQueue[alias];
        if (q?.length) {
            const c = q.shift();
            writeLog(`[EXEC] ${alias} -> ${c}`);
            client.write('text', {
                type: 'chat',
                needs_translation: false,
                source_name: client.username,
                xuid: '',
                platform_chat_id: '',
                filtered_message: '',
                message: c
            });
        }
        client._executorTimer = setTimeout(exec, 3000 + Math.random() * 2000);
    };
    exec();
}

function scheduleLoop(alias, client, cmd, baseMs) {
    if (!client._online) return;
    const makeLoop = () => {
        if (!client._online) return;
        queueCommand(alias, cmd);
        client._loops[cmd] = setTimeout(makeLoop, baseMs + Math.random() * 40000);
    };
    client._loops ??= {};
    client._loops[cmd] = setTimeout(makeLoop, baseMs + Math.random() * 40000);
}

function startAutoTrashLoop(alias, client) {
    if (!client._online) return;
    const autoTrash = async () => {
        if (!client._online) return;
        writeLog(`[AUTO TRASH] ${alias}: Avvio pulizia automatica programmata.`);
        await trashUnwantedItems(client, alias);
        if (client._online) {
            client._autoTrashTimer = setTimeout(autoTrash, 600000);
        }
    };
    client._autoTrashTimer = setTimeout(autoTrash, 600000);
}

function setupInventoryContentListener(client) {
    client.on('inventory_content', (packet) => {
        const key = packet.window_id === 0 ? "inventory" : packet.window_id;
        client.inventory[key] = packet.input;
    });
    client.on('inventory_slot', (packet) => {
        const key = packet.window_id === 0 ? "inventory" : packet.window_id;
        if (client.inventory[key] && Array.isArray(client.inventory[key])) {
            client.inventory[key][packet.slot] = packet.item;
        }
    });
}

function startAllBotsSequentially() {
    writeLog('[SEQUENZA] Interrompo azioni precedenti e avvio join di tutti i bot...');
    currentSequenceId++;
    const thisSequenceId = currentSequenceId;
    const shuffledConfigs = [...botConfigs].sort(() => 0.5 - Math.random());
    shuffledConfigs.forEach((config, i) => {
        const alias = config.alias;
        if (alias === SCANNER_BOT_ALIAS && botMap[alias]?._online) {
            writeLog(`[SEQUENZA] Lo scanner ${alias} è già online. Lo lascio attivo.`);
            delete botStopped[alias];
            return;
        }
        const delay = i * RECONNECTION_STAGGER_MS + Math.random() * 500;
        setTimeout(() => {
            if (currentSequenceId !== thisSequenceId) return;
            delete botStopped[alias];
            delete restartAttempts[alias];
            if (botMap[alias]) safeStopBot(alias);
            createBedrockBot(config, 0);
        }, delay);
    });
}

function stopWorkerBotsSequentially() {
    writeLog('[SEQUENZA] Interrompo azioni precedenti e avvio stop dei worker...');
    currentSequenceId++;
    const thisSequenceId = currentSequenceId;
    const workerBots = Object.keys(botMap).filter(alias => alias !== SCANNER_BOT_ALIAS && botMap[alias]?._online);
    sendTG(`👋 **Segnale di Uscita Rilevato!** Disconnessione di ${workerBots.length} bot in corso...`);
    workerBots.forEach((alias, i) => {
        const delay = i * 13000;
        setTimeout(() => {
            if (currentSequenceId !== thisSequenceId) return;
            writeLog(`[SEQUENZA] Stoppo il worker ${alias}...`);
            botStopped[alias] = true;
            safeStopBot(alias);
        }, delay);
    });
}

function startWorkerBotsSequentially() {
    if (!isScannerModeEnabled) { writeLog('[TRIGGER] Modalità Scanner disattivata. Ignoro.'); return; }
    if (!canTriggerMassLogin) { writeLog('[TRIGGER] Cooldown attivo. Ignoro.'); return; }
    cancelSequentialQuit(); 
    writeLog('[SEQUENZA] Interrompo azioni precedenti e avvio join dei worker...');
    currentSequenceId++;
    const thisSequenceId = currentSequenceId;
    sendTG('🚀 **Segnale di Ingresso Rilevato!** Avvio dei bot worker...');
    canTriggerMassLogin = false;
    const workerBots = botConfigs.filter(cfg => cfg.alias !== SCANNER_BOT_ALIAS);
    workerBots.sort(() => 0.5 - Math.random()).forEach((config, i) => {
        const delay = i * RECONNECTION_STAGGER_MS + Math.random() * 2000;
        setTimeout(() => {
            if (currentSequenceId !== thisSequenceId) return;
            const alias = config.alias;
            delete botStopped[alias];
            delete restartAttempts[alias];
            if (botMap[alias]) safeStopBot(alias);
            createBedrockBot(config, 0);
        }, delay);
    });
    setTimeout(() => { writeLog('[TRIGGER] Cooldown terminato.'); canTriggerMassLogin = true; }, 600000);
}

function safeStopBot(alias) {
    const bot = botMap[alias];
    if (!bot) return;
    if (bot._watchdog) clearInterval(bot._watchdog);
    if (bot._heartbeat) clearInterval(bot._heartbeat);
    if (bot._tradeLoop) bot._tradeLoop = false;
    if (bot._executorTimer) clearTimeout(bot._executorTimer);
    if (bot._autoTrashTimer) clearTimeout(bot._autoTrashTimer);
    Object.values(bot._loops || {}).forEach(clearTimeout);
    if (bot.connection) {
        bot.connection.removeAllListeners('packet');
        bot.connection.removeAllListeners('error');
        bot.connection.removeAllListeners('close');
    }
    delete bot._watchdog;
    delete bot._heartbeat;
    delete bot._loops;
    delete bot._executorTimer;
    delete bot._lastActivity;
    delete bot._isClaiming;
    delete bot._isLinking;
    delete bot._online;
    delete bot._packetHandler;
    delete cmdExecutorFlag[alias];
    delete commandQueue[alias];
    try {
        bot.removeAllListeners();
        bot.connection?.removeAllListeners();
        bot.close();
    } catch {}
    delete botMap[alias];
}

async function createBedrockBot(aliasObj, delay = 0, options = {}) {
    if (delay > 0) await sleep(delay);
    const { alias, name, email } = aliasObj;
    if (botStopped[alias] || (botMap[alias] && botMap[alias]._online)) return;
    writeLog(`[START] ${alias} (${email})`);
    if (delay === 0) sendTG(`🟡 Avvio *${alias}* (tentativo ${restartAttempts[alias] || 1})`);
    let client;
    try {
        const clientOptions = {
            username: name,
            offline: false,
            skipPing: true,
            version: '1.21.100',
            host: HOST,
            port: PORT
        };
        client = bedrock.createClient(clientOptions);
    } catch (e) {
        writeLog(`[CRASH SYNC CAUGHT] ${alias}: Errore Fatale SINCRONO durante createClient. ${e.message}`);
        sendTG(`❌ **CRITICO SYNC:** *${alias}* non può avviare il client. Causa: ${e.message}`);
        if (!botStopped[alias] && !reconnectionQueue.includes(alias)) {
            restartAttempts[alias] = (restartAttempts[alias] || 0) + 1;
            if (restartAttempts[alias] <= MAX_RETRY_ATTEMPTS) {
                reconnectionQueue.push(alias);
                clearTimeout(reconnectionQueueTimer);
                reconnectionQueueTimer = setTimeout(processReconnectionQueue, 5000);
                writeLog(`[QUEUE] ${alias} aggiunto alla coda dopo errore (tentativo ${restartAttempts[alias]})`);
            } else {
                writeLog(`[FATAL] ${alias} ha superato i tentativi. Stop.`);
                botStopped[alias] = true;
            }
        }
        return;
    }
    botMap[alias] = client;
    client.alias = alias;
    client.inventory = {};
    client._isLinking = options.isLinking || false;
    setupInventoryContentListener(client);
    client._lastActivity = Date.now();
    const packetHandler = () => { 
        if (client._online) client._lastActivity = Date.now(); 
    };
    client.on('packet', packetHandler);
    client._packetHandler = packetHandler;
    client._watchdog = setInterval(() => {
        if (!client._online) {
            clearInterval(client._watchdog);
            delete client._watchdog;
            return;
        }
        if (Date.now() - client._lastActivity > 240000) {
            writeLog(`[TIMEOUT] ${alias} inattivo >240s`);
            client.emit('timeout');
        }
    }, 10000);
    bindConnectionEvents(alias, client);
    client.on('join', () => {
        writeLog(`[JOIN] ${alias}`);
        sendTG(`✅ *${alias}* connesso`);
        delete restartAttempts[alias];
        if (client._isClaiming) {
            setTimeout(() => {
                if (!client._online) return;
                immediateCommand(alias, '/server box');
                setTimeout(() => {
                    if (!client._online) return;
                    triggerDailyClaim(client, alias);
                }, 5000);
            }, 23000);
            setTimeout(() => {
                sendTG(`👋 Sequenza di claim per *${alias}* terminata. Disconnessione.`);
                safeStopBot(alias);
            }, 45000);
        } else if (client._isLinking) {
            setTimeout(() => {
                if (!client._online) return;
                immediateCommand(alias, '/server box');
            }, 23000);
            setTimeout(() => {
                writeLog(`[LINKING] ${alias} è in modalità linking. Invio comando /link...`);
                if (client._online) immediateCommand(alias, '/link');
            }, 28000);
        } else {
            setTimeout(() => {
                if (!client._online) return;
                immediateCommand(alias, '/server box');
            }, 23000);
            setTimeout(() => {
                if (!client._online) return;
                ['server box', 'server rizzmines'].forEach(cmd => scheduleLoop(alias, client, `/${cmd}`, 400000));
                startCommandExecutor(alias, client);
                startAutoTrashLoop(alias, client);
            }, 5000 + Math.random() * 10000);
        }
    });
    client.on('text', (packet) => {
        const strippedMessage = packet.message?.trim().replace(/(&|§|\u00A7)[0-9a-fk-or]/gi, '');
        if (!strippedMessage) return;
        
        if (packet.type === 'system' || packet.type === 'tip' || packet.type === 'translation') {
            const lowerMsg = strippedMessage.toLowerCase();
            if (lowerMsg.includes('captcha')) {
                writeLog(`[CAPTCHA DETECTED] ${alias}: Tipo=${packet.type}, Messaggio="${strippedMessage}"`);
                sendTG(`🚨 **CAPTCHA RILEVATO!**\n*Bot:* ${alias}\n*Tipo:* ${packet.type}\n*Messaggio:* ${strippedMessage.substring(0, 200)}`);
            }
        }
        
        if (client._isLinking) {
            const linkCodeRegex = /Your link code is (\d{4,})\./;
            const match = strippedMessage.match(linkCodeRegex);
            if (match && match[1]) {
                const code = match[1];
                const botName = client.username;
                writeLog(`[LINKING] Codice trovato per ${botName}: ${code}`);
                sendTG(`✅ **Link Code Rilevato:**\n\`${botName}:${code}\``);
                client._isLinking = false;
            }
        }
        if (alias === SCANNER_BOT_ALIAS && isScannerModeEnabled) {
            const lowerCaseMessage = strippedMessage.toLowerCase();
            if (lowerCaseMessage.includes('global token-all in 1 minute')) {
                if (quitSequenceTimeout) clearTimeout(quitSequenceTimeout);
                writeLog('[SEQUENZA] Segnale di ingresso ricevuto. Avvio bot e timer di sicurezza di 3 minuti.');
                sendTG('🚀 **Segnale di Ingresso!** Avvio dei bot e del timer di uscita di sicurezza...');
                startWorkerBotsSequentially();
                isQuitPending = true;
                quitSequenceTimeout = setTimeout(() => {
                    writeLog('[SEQUENZA] Timeout di sicurezza scaduto. Messaggio di bonus non ricevuto. Avvio disconnessione.');
                    sendTG('⏰ Timeout di sicurezza scaduto. Avvio disconnessione...');
                    if(isQuitPending) {
                        isQuitPending = false;
                        stopWorkerBotsSequentially();
                    }
                }, 180000);
            } else if (lowerCaseMessage.includes('all players have received a bonus token')) {
                if (isQuitPending) {
                    writeLog('[SEQUENZA] Bonus ricevuto. Avvio disconnessione come programmato.');
                    sendTG('✅ **Bonus Ricevuto!** Avvio disconnessione...');
                    clearTimeout(quitSequenceTimeout);
                    isQuitPending = false;
                    stopWorkerBotsSequentially();
                }
            }
        }
    });
    client.on('start_game', (packet) => {
        client._currentPos = packet.player_position || { x: 0, y: 0, z: 0 };
        client._currentYaw = packet.rotation?.y || 0;
        client._currentPitch = packet.rotation?.x || 0;
        let tick = 0;
        client._heartbeat = setInterval(() => {
            if (!client._online) {
                clearInterval(client._heartbeat);
                return;
            }
            const yawChange = (Math.random() - 0.5) * 8;
            const pitchChange = (Math.random() - 0.5) * 6;
            client._currentYaw += yawChange;
            client._currentPitch = Math.max(-89, Math.min(89, client._currentPitch + pitchChange));
            while (client._currentYaw > 360) client._currentYaw -= 360;
            while (client._currentYaw < -360) client._currentYaw += 360;
            const pitchRad = client._currentPitch * (Math.PI / 180);
            const yawRad = client._currentYaw * (Math.PI / 180);
            const cosPitch = Math.cos(pitchRad);
            const camVecX = -cosPitch * Math.sin(yawRad);
            const camVecY = -Math.sin(pitchRad);
            const camVecZ = cosPitch * Math.cos(yawRad);
            const posVariation = {
                x: client._currentPos.x + (Math.random() - 0.5) * 0.001,
                y: client._currentPos.y,
                z: client._currentPos.z + (Math.random() - 0.5) * 0.001
            };
            try {
                client.queue("player_auth_input", {
                    pitch: client._currentPitch,
                    yaw: client._currentYaw,
                    position: posVariation,
                    move_vector: { x: 0, z: 0 },
                    head_yaw: client._currentYaw,
                    input_data: {
                        "_value": 1407374883553280n,
                        sprinting: false,
                        sneaking: false,
                        block_breaking_delay_enabled: true,
                        vertical_collision: true
                    },
                    input_mode: "mouse",
                    play_mode: "screen",
                    interaction_model: "touch",
                    interact_rotation: {
                        x: client._currentPitch,
                        z: client._currentYaw
                    },
                    tick: BigInt(tick++),
                    delta: { x: 0, y: -0.07840000092983246, z: 0 },
                    analogue_move_vector: { x: 0, z: 0 },
                    camera_orientation: { x: camVecX, y: camVecY, z: camVecZ },
                    raw_move_vector: { x: 0, z: 0 }
                });
            } catch (err) {
                writeLog(`[ERROR] ${client.alias}: Errore invio player_auth_input: ${err.message}`);
            }
        }, 50);
    });
}

async function trashUnwantedItems(client, alias) {
    writeLog(`[TRASH ITEMS] ${alias}: Avvio procedura di eliminazione item non necessari.`);
    await sleep(2000);
    const playerInventory = client.inventory?.inventory || [];
    const unwantedSlots = [];
    for (let i = 0; i < playerInventory.length; i++) {
        const item = playerInventory[i];
        if (item && item.network_id !== 0) {
            if (item.network_id !== TOKEN_ITEM_NETWORK_ID && 
                item.network_id !== KEY_ITEM_NETWORK_ID && 
                item.network_id !== HOTDOG_ITEM_NETWORK_ID) {
                unwantedSlots.push({
                    slot: i,
                    count: item.count,
                    stack_id: item.stack_id,
                    network_id: item.network_id
                });
            }
        }
    }
    if (unwantedSlots.length === 0) {
        writeLog(`[TRASH ITEMS] ${alias}: Nessun item non necessario trovato.`);
        return;
    }
    writeLog(`[TRASH ITEMS] ${alias}: Trovati ${unwantedSlots.length} slot con item da eliminare.`);
}

async function triggerDailyClaim(client, alias) {
    if (!client?._online) {
        writeLog(`[CLAIM] Tentativo di claim fallito per ${alias} (offline).`);
        return;
    }
    writeLog(`[CLAIM] ${alias} avvia la procedura di riscossione premio...`);
    sendTG(`💰 Avvio riscossione per *${alias}*...`);
    immediateCommand(alias, '/daily');
}

function bindConnectionEvents(alias, client) {
    const setOffline = (why) => {
        if (!client._online) return;
        client._online = false;
        writeLog(`[OFFLINE] ${alias}: ${why}`);
        safeStopBot(alias);
        if (botStopped[alias]) return;
        if (isScannerModeEnabled && alias !== SCANNER_BOT_ALIAS) {
            writeLog(`[RETRY] ${alias} è un worker in modalità Scanner. Non si riconnetterà automaticamente.`);
            return;
        }
        restartAttempts[alias] = (restartAttempts[alias] || 0) + 1;
        const attempts = restartAttempts[alias];
        writeLog(`[RETRY] ${alias} - Tentativo di riconnessione numero ${attempts}/${MAX_RETRY_ATTEMPTS}.`);
        if (attempts > MAX_RETRY_ATTEMPTS) {
            writeLog(`[FATAL] ${alias} ha superato ${MAX_RETRY_ATTEMPTS} tentativi. Stop permanente.`);
            sendTG(`❌ **CRITICO:** *${alias}* ha fallito il riavvio per ${MAX_RETRY_ATTEMPTS} volte.`);
            botStopped[alias] = true;
            return;
        }
        if (!reconnectionQueue.includes(alias)) {
            writeLog(`[QUEUE] ${alias} aggiunto alla coda di riconnessione.`);
            reconnectionQueue.push(alias);
            clearTimeout(reconnectionQueueTimer);
            reconnectionQueueTimer = setTimeout(processReconnectionQueue, 5000);
        }
    };
    client._online = true;
    client.on('close', () => setOffline('close'));
    client.on('kick', (reason) => setOffline(`kick: ${reason?.message}`));
    client.on('error', e => setOffline(`error: ${e.message}`));
    client.on('timeout', () => setOffline('timeout'));
    return { setOffline };
}

function setupDailyScheduler() {
    writeLog('[SCHEDULER] Pianificatore per sequenza giornaliera attivato.');
    const checkAndRun = () => {
        if (!isScannerModeEnabled) return;
        const now = Date.now();
        const twentyFourHoursAndOneMinute = (24 * 60 * 60 * 1000) + (60 * 1000);
        if (now > dailyState.lastRun + twentyFourHoursAndOneMinute) {
            writeLog('[SCHEDULER] È ora di eseguire il claim giornaliero automatico.');
        }
    };
    setInterval(checkAndRun, 60000); 
}

if (isScannerModeEnabled) {
    const scannerConfig = botConfigs.find(cfg => cfg.alias === SCANNER_BOT_ALIAS);
    if (scannerConfig) {
        writeLog(`[AVVIO] Modalità Scanner. Avvio di ${SCANNER_BOT_ALIAS}. In attesa del segnale...`);
        createBedrockBot(scannerConfig, 0);
    } else {
        writeLog(`[ERRORE FATALE] Bot scanner "${SCANNER_BOT_ALIAS}" non trovato in accounts.json!`);
        process.exit(1);
    }
} else {
    writeLog("[AVVIO] Modalità Continua. Avvio di tutti i bot in sequenza.");
    startAllBotsSequentially();
}

writeLog('[INIT] Bot Bedrock Protocol avviato con successo!');
loadDailyState();
setupDailyScheduler();

setInterval(() => {
    const mem = process.memoryUsage();
    writeLog(`[MEM] RSS=${(mem.rss/1024/1024).toFixed(1)}MB | Heap=${(mem.heapUsed/1024/1024).toFixed(1)}MB/${(mem.heapTotal/1024/1024).toFixed(1)}MB`);
    Object.keys(commandQueue).forEach(alias => {
        if (!botMap[alias] || commandQueue[alias]?.length === 0) {
            delete commandQueue[alias];
        }
    });
    if (global.gc && mem.heapUsed / mem.heapTotal > 0.9) {
        writeLog('[MEM] Heap usage >90%, triggering GC...');
        global.gc();
    }
}, 600000);
