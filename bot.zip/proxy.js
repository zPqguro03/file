// Aggiungiamo 'util' per una stampa più pulita degli oggetti complessi
const util = require('util'); 
const { Relay } = require('bedrock-protocol');

console.log(`[Sniffer] Avvio del Relay in modalità LOGGING...`);

const relay = new Relay({
    version: '1.21.100',
    host: '0.0.0.0',
    port: 19132,
    destination: {
        host: 'rizzmines.bedrock.minehut.gg',
        port: 19132,
        skipPing: true
    }
});

relay.listen();

console.log(`[Sniffer] 🟢 Ascolto avviato su 0.0.0.0:${relay.options.port}`);
console.log(`[Sniffer] ➡️  Traffico inoltrato a ${relay.options.destination.host}:${relay.options.destination.port}`);

// Quando un client si connette...
/* relay.on('connect', player => {
    console.log(`[Sniffer] 🕵️  Client connesso: ${player.id}. Inizio sniffing pacchetti S2C...`);

    // ...agganciamo lo sniffer per ascoltare i pacchetti inviati DAL SERVER AL CLIENT.
    player.on('clientbound', ({ name, params }) => {
        
        // Stampa il nome del pacchetto in modo chiaro
        console.log(`\n==================== [S2C Packet Received] ====================`);
        console.log(`➡️  Nome Pacchetto: ${name}`);
        
        // Stampa i parametri del pacchetto in modo dettagliato e leggibile
        // 'util.inspect' è più sicuro di JSON.stringify per oggetti complessi
        console.log('📋 Parametri:');
        console.log(util.inspect(params, { 
            showHidden: false, 
            depth: 5, // Aumenta la profondità se gli oggetti sono molto annidati
            colors: true // Usa i colori per una migliore leggibilità
        }));
        console.log(`=============================================================`);
    });
}); */

relay.on('close', player => {
    console.log(`[Sniffer] 🔌 Client disconnesso: ${player.id}. Sniffing interrotto.`);
});

relay.on('error', err => {
    console.error(`[Sniffer] ❗️ Errore critico nel Relay:`, err);
});